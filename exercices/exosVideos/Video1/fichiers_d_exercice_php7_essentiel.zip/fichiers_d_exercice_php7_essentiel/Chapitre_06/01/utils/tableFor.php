<?php

$arr = ['Orange', 'Citron', 'Mandarine'];

$arr['subArray'] = $arr;

var_dump($arr); die;