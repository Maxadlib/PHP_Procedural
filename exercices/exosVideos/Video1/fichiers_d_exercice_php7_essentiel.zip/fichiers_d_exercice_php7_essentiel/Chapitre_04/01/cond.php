<?php

$var = 3;
$varEqualOne = 1 == $var;
$varEqualTwo = 2 == $var;

if ($varEqualOne) {
    echo "var equal 1";
} else if ($varEqualTwo) {
    echo "var equal 2";
}

// PSR