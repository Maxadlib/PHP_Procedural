<?php

$i = 0;

while ($i <= 10) {
    var_dump($i);

    ++$i;

    var_dump($i);
    var_dump('-----------');
}

