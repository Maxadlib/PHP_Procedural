<?php

$var = null;
$name = $var ?: 'Julien';

echo "name : $name\n";