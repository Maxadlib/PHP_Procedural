<?php

$var = 2;
$varEqualOne = 1 == $var;
$varEqualTwo = 2 == $var;

if ($varEqualOne)
    echo "var equal 1";

// PSR