<?php

$hello = "Hello";
$name = "Julien";

?>

<!DOCTYPE html>
<html>
<body>

<h1>My first PHP page</h1>

<?php echo $hello; ?> <?php echo $name; ?>!

<?php

$name = "Christophe";

?>

<?php echo $hello; ?> <?php echo $name; ?>!

</body>
</html>