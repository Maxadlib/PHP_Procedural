<?php

$arr = [
    'name' => 'Julien',
    'age' => '25ans',
    'location' => [
        'city' => 'Paris'
    ]
];

$arr['status'] = 'ok';

echo var_dump($arr);