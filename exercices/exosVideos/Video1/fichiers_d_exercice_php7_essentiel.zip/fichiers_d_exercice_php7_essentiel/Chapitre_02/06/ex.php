<?php

$name = "Julien";

echo <<<EOT
Hello $name!
Welcome!
EOT;
