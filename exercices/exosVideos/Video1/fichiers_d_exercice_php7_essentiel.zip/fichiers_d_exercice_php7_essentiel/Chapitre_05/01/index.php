<?php include 'header.php'; ?>

<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet doloremque iure maiores modi mollitia omnis, perspiciatis! Fugiat itaque nemo quaerat recusandae sequi voluptate. Consectetur ducimus eum mollitia odit quam quia.</p>

<?php include 'footer.php'; ?>