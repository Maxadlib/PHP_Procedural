<?php

require_once 'object.php';

$newCar = new Car(20);

var_dump($newCar);