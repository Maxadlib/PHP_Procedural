<?php require __DIR__ . '/class/resolver.php'; ?>

<?php (new resolver(__DIR__, 'inc', 'header'))->requireFile() ?>

<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet doloremque iure maiores modi mollitia omnis, perspiciatis! Fugiat itaque nemo quaerat recusandae sequi voluptate. Consectetur ducimus eum mollitia odit quam quia.</p>

<?php (new resolver(__DIR__, 'inc', 'footer'))->requireFile() ?>