<?php

require_once __DIR__ . '/../class/object.php';

$newCar = new Car(20);

var_dump($newCar);