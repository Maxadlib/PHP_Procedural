<?php

$i = 0;

while ($i <= 10) {
    echo "i = $i\n";

    $i = $i + 1;
}

