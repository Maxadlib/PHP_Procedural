<?php

/**
 *
 */
function displayInformation() {
    echo sprintf("Hello!\n");
}

displayInformation();