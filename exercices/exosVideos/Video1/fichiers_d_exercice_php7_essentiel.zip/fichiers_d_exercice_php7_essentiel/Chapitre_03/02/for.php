<?php

for ($i = 0; $i <= 10; $i = $i+1) {
    echo "i = $i\n";
}