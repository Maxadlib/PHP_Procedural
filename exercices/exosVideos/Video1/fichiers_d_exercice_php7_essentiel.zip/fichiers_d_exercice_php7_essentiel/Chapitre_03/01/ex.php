<?php
    $name = "Julien";
?>

<!doctype html>
<html lang="en">
<head>
    <title></title>
</head>
<body>
    Hello <?php echo $name ?>!
</body>
</html>